const express = require('express');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
require('dotenv').config();

const app = express();
const corsOptions = process.env.CORS_ORIGIN ? { origin: process.env.CORS_ORIGIN } : undefined;
app.use(cors(corsOptions));
app.use(express.json());

const DATA_FILE = path.join(__dirname, 'data', 'data.json');

async function fetchRecordsFromFile() {
  const raw = fs.readFileSync(DATA_FILE, 'utf8');
  const arr = JSON.parse(raw);
  return arr.map(r => ({ date: r.date.split('T')[0], codes: r.codes }));
}

function aggregate(records, days, top) {
  const now = new Date();
  let cutoff = null;
  if (days) {
    cutoff = new Date(now.getTime() - (days * 24 * 60 * 60 * 1000));
  }
  const filtered = cutoff ? records.filter(r => new Date(r.date) >= cutoff) : records;
  const codesByDate = new Map();
  filtered.forEach(r => {
    const d = r.date || null;
    if (!d) return;
    if (!codesByDate.has(d)) codesByDate.set(d, new Set());
    (r.codes || []).forEach(code => { if (code) codesByDate.get(d).add(String(code)); });
  });
  const totalDays = codesByDate.size || 0;
  const counts = {};
  for (const set of codesByDate.values()) {
    for (const code of set) {
      counts[code] = (counts[code] || 0) + 1;
    }
  }
  const items = Object.keys(counts).map(code => ({ code, count: counts[code], percent: totalDays ? Math.round((counts[code] / totalDays) * 100) : 0 }));
  items.sort((a, b) => b.count - a.count);
  return { totalDays, items: items.slice(0, top || items.length) };
}

async function aggregateFromMongo(days, top) {
  const { MongoClient } = require('mongodb');
  const uri = process.env.MONGO_URI;
  if (!uri) throw new Error('MONGO_URI not set');
  const client = new MongoClient(uri);
  await client.connect();
  try {
    const db = client.db(process.env.MONGO_DBNAME);
    const coll = db.collection(process.env.MONGO_COLLECTION || 'records');

    const pipeline = [];
    pipeline.push({ $addFields: { dateStr: { $ifNull: ['$datetime', '$date'] } } });
    pipeline.push({
      $addFields: {
        dateNormalized: {
          $cond: [
            { $ifNull: ['$datetime', false] },
            { $dateToString: { format: '%Y-%m-%d', date: '$datetime' } },
            {
              $cond: [
                { $regexMatch: { input: '$date', regex: '^\\d{2}-\\d{2}-\\d{4}$' } },
                { $let: { vars: { parts: { $split: ['$date', '-'] } }, in: { $concat: [{ $arrayElemAt: ['$$parts', 2] }, '-', { $arrayElemAt: ['$$parts', 1] }, '-', { $arrayElemAt: ['$$parts', 0] }] } } },
                { $substrCP: ['$date', 0, 10] }
              ]
            }
          ]
        }
      }
    });
    pipeline.push({
      $project: {
        dateNormalized: 1,
        codes: { $cond: [{ $isArray: '$codes' }, '$codes', { $cond: [{ $ifNull: ['$code', false] }, ['$code'], []] }] },
        profit_percent: 1
      }
    });
    pipeline.push({ $unwind: '$codes' });
    pipeline.push({ $match: { dateNormalized: { $ne: null } } });

    if (days) {
      const now = new Date();
      const cutoff = new Date(now.getTime() - (days * 24 * 60 * 60 * 1000));
      const cutoffStr = cutoff.toISOString().split('T')[0];
      pipeline.push({ $match: { dateNormalized: { $gte: cutoffStr } } });
    }

    // group by date+code to get max profit per day-code
    pipeline.push({ $group: { _id: { date: '$dateNormalized', code: '$codes' }, maxProfitPerDayCode: { $max: '$profit_percent' } } });
    // then group by code to count distinct days and overall max profit
    pipeline.push({ $group: { _id: '$_id.code', count: { $sum: 1 }, maxProfit: { $max: '$maxProfitPerDayCode' } } });
    pipeline.push({ $sort: { count: -1 } });
    pipeline.push({ $limit: top || 100 });

    const itemsRaw = await coll.aggregate(pipeline).toArray();
    const items = itemsRaw.map(r => ({ code: r._id, count: r.count, maxProfit: (typeof r.maxProfit === 'number') ? r.maxProfit : null }));

    // total distinct days
    const dayPipeline = [];
    dayPipeline.push({ $addFields: { dateStr: { $ifNull: ['$datetime', '$date'] } } });
    dayPipeline.push({ $addFields: { dateNormalized: {
      $cond: [
        { $ifNull: ['$datetime', false] },
        { $dateToString: { format: '%Y-%m-%d', date: '$datetime' } },
        { $cond: [ { $regexMatch: { input: '$date', regex: '^\\d{2}-\\d{2}-\\d{4}$' } }, { $let: { vars: { parts: { $split: ['$date', '-'] } }, in: { $concat: [{ $arrayElemAt: ['$$parts',2] }, '-', { $arrayElemAt: ['$$parts',1] }, '-', { $arrayElemAt: ['$$parts',0] }] } } }, { $substrCP: ['$date',0,10] } ] }
      ]
    } } });
    dayPipeline.push({ $match: { dateNormalized: { $ne: null } } });
    if (days) {
      const now = new Date();
      const cutoff = new Date(now.getTime() - (days * 24 * 60 * 60 * 1000));
      const cutoffStr = cutoff.toISOString().split('T')[0];
      dayPipeline.push({ $match: { dateNormalized: { $gte: cutoffStr } } });
    }
    dayPipeline.push({ $group: { _id: '$dateNormalized' } });
    dayPipeline.push({ $count: 'totalDays' });
    const dayRes = await coll.aggregate(dayPipeline).toArray();
    const totalDays = dayRes.length ? dayRes[0].totalDays : 0;

    const enriched = items.map(i => ({ code: i.code, count: i.count, percent: totalDays ? Math.round((i.count / totalDays) * 100) : 0, maxProfit: i.maxProfit }));
    return { totalDays, items: enriched };
  } finally {
    await client.close();
  }
}

// Simple in-memory cache to reduce repeated heavy DB aggregation
const aggCache = new Map(); // key -> { ts, data }
const CACHE_TTL_MS = process.env.AGG_CACHE_TTL_MS ? parseInt(process.env.AGG_CACHE_TTL_MS, 10) : 15000;

async function getCachedAggregation(days, top) {
  const key = `d:${days||'all'}:t:${top||100}`;
  const now = Date.now();
  const entry = aggCache.get(key);
  if (entry && (now - entry.ts) < CACHE_TTL_MS) return entry.data;
  const data = await aggregateFromMongo(days, top);
  aggCache.set(key, { ts: now, data });
  return data;
}

app.get('/api/data', async (req, res) => {
  try {
    const days = req.query.days ? parseInt(req.query.days, 10) : null;
    const top = req.query.top ? parseInt(req.query.top, 10) : 10;
    if (process.env.MONGO_URI) {
      const agg = await getCachedAggregation(days, top);
      res.json(Object.assign({ source: 'mongo' }, agg));
      return;
    }
    const records = await fetchRecordsFromFile();
    const result = aggregate(records, days, top);
    res.json({ source: 'file', totalDays: result.totalDays, items: result.items });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/sample', async (req, res) => {
  try {
    if (process.env.MONGO_URI) {
      const { MongoClient } = require('mongodb');
      const uri = process.env.MONGO_URI;
      const client = new MongoClient(uri);
      await client.connect();
      try {
        const db = client.db(process.env.MONGO_DBNAME);
        const coll = db.collection(process.env.MONGO_COLLECTION || 'records');
        const docs = await coll.find({}).limit(20).toArray();
        res.json({ source: 'mongo', sampleCount: docs.length, docs });
        return;
      } finally {
        await client.close();
      }
    }
    const records = await fetchRecordsFromFile();
    res.json({ source: 'file', sampleCount: records.length, docs: records.slice(0, 20) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/daily-counts?month=YYYY-MM OR ?start=YYYY-MM-DD&end=YYYY-MM-DD
app.get('/api/daily-counts', async (req, res) => {
  try {
    if (!process.env.MONGO_URI) {
      // fallback to file-based calculation
      const records = await fetchRecordsFromFile();
      const { start, end } = req.query;
      let startDate = start ? new Date(start) : null;
      let endDate = end ? new Date(end) : null;
      if (req.query.month) {
        const [y, m] = req.query.month.split('-').map(Number);
        startDate = new Date(y, m - 1, 1);
        endDate = new Date(y, m, 0); // last day
      }
      const filtered = records.filter(r => {
        const d = new Date(r.date);
        if (startDate && d < startDate) return false;
        if (endDate && d > endDate) return false;
        return true;
      });
      const byDate = new Map();
      filtered.forEach(r => {
        const d = r.date;
        if (!byDate.has(d)) byDate.set(d, new Set());
        (r.codes || []).forEach(c => byDate.get(d).add(String(c)));
      });
      const days = Array.from(byDate.entries()).map(([date, set]) => ({ date, count: set.size }));
      days.sort((a, b) => a.date.localeCompare(b.date));
      res.json({ source: 'file', range: { start: startDate?.toISOString().split('T')[0] || null, end: endDate?.toISOString().split('T')[0] || null }, days });
      return;
    }

    // Mongo path
    const { MongoClient } = require('mongodb');
    const uri = process.env.MONGO_URI;
    const client = new MongoClient(uri);
    await client.connect();
    try {
      const db = client.db(process.env.MONGO_DBNAME);
      const coll = db.collection(process.env.MONGO_COLLECTION || 'records');
      // determine start/end
      let startDateStr = req.query.start || null;
      let endDateStr = req.query.end || null;
      if (req.query.month) {
        const [y, m] = req.query.month.split('-').map(Number);
        const start = new Date(y, m - 1, 1);
        const end = new Date(y, m, 0);
        startDateStr = start.toISOString().split('T')[0];
        endDateStr = end.toISOString().split('T')[0];
      }

      const pipeline = [];
      pipeline.push({ $addFields: { dateStr: { $ifNull: ['$datetime', '$date'] } } });
      pipeline.push({
        $addFields: {
          dateNormalized: {
            $cond: [
              { $ifNull: ['$datetime', false] },
              { $dateToString: { format: '%Y-%m-%d', date: '$datetime' } },
              {
                $cond: [
                  { $regexMatch: { input: '$date', regex: '^\\d{2}-\\d{2}-\\d{4}$' } },
                  { $let: { vars: { parts: { $split: ['$date', '-'] } }, in: { $concat: [{ $arrayElemAt: ['$$parts',2] }, '-', { $arrayElemAt: ['$$parts',1] }, '-', { $arrayElemAt: ['$$parts',0] }] } } },
                  { $substrCP: ['$date', 0, 10] }
                ]
              }
            ]
          }
        }
      });
      pipeline.push({ $project: { dateNormalized: 1, codes: { $cond: [{ $isArray: '$codes' }, '$codes', { $cond: [{ $ifNull: ['$code', false] }, ['$code'], []] }] } } });
      pipeline.push({ $unwind: '$codes' });
      pipeline.push({ $match: { dateNormalized: { $ne: null } } });
      if (startDateStr || endDateStr) {
        const matchObj = {};
        if (startDateStr) matchObj.$gte = startDateStr;
        if (endDateStr) matchObj.$lte = endDateStr;
        pipeline.push({ $match: { dateNormalized: matchObj } });
      }
      // collect unique codes per day
      pipeline.push({ $group: { _id: { date: '$dateNormalized' }, codesSet: { $addToSet: '$codes' } } });
      pipeline.push({ $project: { date: '$_id.date', count: { $size: '$codesSet' } } });
      pipeline.push({ $sort: { date: 1 } });

      const days = await coll.aggregate(pipeline).toArray();
      res.json({ source: 'mongo', range: { start: startDateStr, end: endDateStr }, days });
    } finally {
      await client.close();
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

app.use('/', express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';
app.listen(PORT, HOST, () => console.log(`Server running on http://${HOST}:${PORT} (accessible externally)`));
