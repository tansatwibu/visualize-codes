const tableBody = document.querySelector('#codes-table tbody');
const buttons = document.querySelectorAll('.range-buttons button');
const loader = document.getElementById('loader');
const monthPicker = document.getElementById('monthPicker');
let currentDays = 30;
let chart = null;
const clientCache = new Map();

function showLoader(on){ loader.style.display = on ? 'block' : 'none'; }

async function load(days = 30) {
  const key = `d:${days}`;
  if (clientCache.has(key)) {
    const json = clientCache.get(key);
    renderTable(json.items);
    return;
  }
  try {
    showLoader(true);
    buttons.forEach(b => b.classList.add('btn-disabled'));
    const res = await fetch(`/api/data?days=${days}&top=8`);
    const json = await res.json();
    clientCache.set(key, json);
    renderTable(json.items);
    // prefetch other ranges to reduce delay on tab switch
    prefetchRanges([30,60,90,365].filter(n => n !== days));
  } finally {
    showLoader(false);
    buttons.forEach(b => b.classList.remove('btn-disabled'));
  }
}

function prefetchRanges(ranges){
  ranges.forEach(d => {
    const key = `d:${d}`;
    if (clientCache.has(key)) return;
    fetch(`/api/data?days=${d}&top=8`).then(r=>r.json()).then(j=>clientCache.set(key,j)).catch(()=>{});
  });
}

function renderTable(items) {
  tableBody.innerHTML = '';
  items.forEach(it => {
    const tr = document.createElement('tr');
    const maxProfitDisplay = (it.maxProfit != null) ? (Number(it.maxProfit) * 100).toFixed(2) + '%' : '-';
    tr.innerHTML = `<td>${it.code}</td><td>${it.count}</td><td>${maxProfitDisplay}</td>`;
    tableBody.appendChild(tr);
  });
}

function renderChart(items) {
  const ctx = document.getElementById('barChart').getContext('2d');
  const labels = items.map(i => i.code);
  const data = items.map(i => i.count);
  if (chart) chart.destroy();
  chart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{ label: 'Số ngày xuất hiện', data, backgroundColor: ['#cfe8ff','#b6d4ff','#9fc0ff','#88acff','#7198ff','#5b84ff','#446fff','#2d5bff'] }]
    },
    options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
  });
}

function renderDailyChart(days) {
  const ctx = document.getElementById('barChart').getContext('2d');
  const labels = days.map(d => d.date);
  const data = days.map(d => d.count);
  if (chart) chart.destroy();
  chart = new Chart(ctx, {
    type: 'bar',
    data: { labels, datasets: [{ label: 'Số mã xuất hiện', data, backgroundColor: '#79b8ff' }] },
    options: { responsive: true, plugins: { legend: { display: false }, tooltip: { callbacks: { label: (ctx) => `${ctx.parsed.y} mã` } } }, scales: { y: { beginAtZero: true } } }
  });
}

async function loadDailyCounts(month) {
  const key = `month:${month}`;
  if (clientCache.has(key)) {
    renderDailyChart(clientCache.get(key).days);
    return;
  }
  try {
    showLoader(true);
    const res = await fetch(`/api/daily-counts?month=${month}`);
    const json = await res.json();
    clientCache.set(key, json);
    renderDailyChart(json.days);
  } catch (e) {
    console.error(e);
  } finally {
    showLoader(false);
  }
}

buttons.forEach(b => b.addEventListener('click', () => {
  buttons.forEach(x => x.classList.remove('active'));
  b.classList.add('active');
  currentDays = parseInt(b.dataset.days, 10);
  load(currentDays);
}));

// initialize month picker to current month and load daily counts
const now = new Date();
const defaultMonth = now.toISOString().slice(0,7); // YYYY-MM
if (monthPicker) {
  monthPicker.value = defaultMonth;
  monthPicker.addEventListener('change', () => {
    const m = monthPicker.value;
    if (m) loadDailyCounts(m);
  });
  // load daily counts for default month
  loadDailyCounts(defaultMonth).catch(err => console.error(err));
}

// also load top codes view (table) in background
load(currentDays).catch(err => console.error(err));
