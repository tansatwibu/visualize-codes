# Visualize Codes by Days

Simple web app that displays how many days each code appears in the dataset. It uses a sample `data/data.json` by default and can be switched to MongoDB by setting environment variables.

Quick start

1. Install dependencies

```bash
cd d:/works/visualize-codes
npm install
```

2. Run locally

```bash
npm start
# open http://localhost:3000
```

Development

```bash
npm run dev
```

Using a real MongoDB database

Set the following environment variables (for example in a `.env` file):
 - Set the following environment variables (for example in a `.env` file):

```
MONGO_URI=mongodb+srv://user:pass@host/mydb
MONGO_DBNAME=mydb          # optional
MONGO_COLLECTION=records  # optional, default 'records'
CORS_ORIGIN=                # optional, restrict access to a single origin (e.g. https://example.com). Leave empty to allow all.
```

Expected Mongo document shape (one document per day):

```json
{ "date": "2026-08-29", "codes": ["ACB","HPG","VIC"] }
```

API

- `GET /api/data?days=30&top=8` — returns top codes, their counts and percent of days in the requested period.

Notes

- The frontend buttons map to the `days` query parameter.
- `percent` is `count / totalDays * 100` rounded to integer.

Run on a remote server or different device

- You only need to change the `MONGO_URI` (and optionally `CORS_ORIGIN`) to point to your MongoDB that contains the imported `data.json` documents. No code changes required.
- Ensure the server is reachable from clients: if running on a VM or server, open the chosen `PORT` (default `3000`) in firewall and use the server's public IP or domain when opening the site from another device.

Using Docker

1. Build and run with environment variables:

```bash
# set these in environment or in an .env file
docker-compose up --build -d
```

2. Provide `MONGO_URI` etc. as environment variables (e.g. exported in shell or in a `.env` file for docker-compose). The container reads the env and will connect to your remote MongoDB.

Security note

- Do not expose an open MongoDB URI publicly. Keep credentials secure and restrict access to trusted IPs. Use `CORS_ORIGIN` to limit which frontends can access the API.

